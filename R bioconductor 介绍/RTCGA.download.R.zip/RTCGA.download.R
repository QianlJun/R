# Download from RTCGA
library(RTCGA)

### Prepare for downloading
# retrieve all NAMEs of tumor types 
allstudy <- infoTCGA()
View(allstudy) #allstudy$Cohort; for example "STAD"

# retrieve all studies related to a tumor type; for example "STAD"
datatype <- checkTCGA('DataSets', cancerType = 'STAD')
View(datatype)

# retrieve the data versions; for example, the most recent
checkTCGA('Dates')
#select the second most recent release
releaseDate <- tail(checkTCGA('Dates'),1)
releaseDate

### Downloading data
# for example: download STAD miRseq data processed on 2016-01-28
dir.create('STAD')
downloadTCGA(cancerTypes = 'STAD', dataSet = datatype[36,'Name'], 
             destDir = 'STAD', date = releaseDate )
